import java.sql.Connection;
import java.sql.DriverManager;

public class ConexaoBanco {
    public static Connection obterConexao() {
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/CadastroPessoas", "root", "");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
// alanzin 3,14 <3