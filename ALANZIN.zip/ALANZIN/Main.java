import java.util.List;
import java.util.Scanner;

public class Aplicacao {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Pessoa novaPessoa = new Pessoa();

        System.out.print("Por favor, escreva seu nome: ");
        novaPessoa.setNomeCompleto(entrada.nextLine());

        System.out.print("Por favor, digite seu documento (CPF): ");
        novaPessoa.setDocumento(entrada.nextLine());

        System.out.print("Por favor, digite seu email: ");
        novaPessoa.setContatoEmail(entrada.nextLine());

        System.out.print("Por favor, digite seu telefone: ");
        novaPessoa.setCelular(entrada.nextLine());

        System.out.print("Por favor, digite seu endereço: ");
        novaPessoa.setLocalResidencia(entrada.nextLine());

        PessoaDAO dao = new PessoaDAO();
        dao.adicionarPessoa(novaPessoa);

        List<Pessoa> pessoas = dao.listarPessoas();
        for (Pessoa p : pessoas) {
            System.out.println("Nome: " + p.getNomeCompleto() + " | Documento: " + p.getDocumento());
        }

        entrada.close();
    }
}
// alanzin 3,14 <3