import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PessoaDAO {
    public void adicionarPessoa(Pessoa p) {
        try {
            Connection conexao = ConexaoBanco.obterConexao();
            String sql = "INSERT INTO registros (nome_completo, documento, contato_email, celular, local_residencia) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement comando = conexao.prepareStatement(sql);
            comando.setString(1, p.getNomeCompleto());
            comando.setString(2, p.getDocumento());
            comando.setString(3, p.getContatoEmail());
            comando.setString(4, p.getCelular());
            comando.setString(5, p.getLocalResidencia());
            comando.execute();
            conexao.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Pessoa> listarPessoas() {
        List<Pessoa> lista = new ArrayList<>();
        try {
            Connection conexao = ConexaoBanco.obterConexao();
            String sql = "SELECT * FROM registros";
            PreparedStatement comando = conexao.prepareStatement(sql);
            ResultSet resultado = comando.executeQuery();
            while (resultado.next()) {
                Pessoa p = new Pessoa();
                p.setCodigo(resultado.getInt("codigo"));
                p.setNomeCompleto(resultado.getString("nome_completo"));
                p.setDocumento(resultado.getString("documento"));
                p.setContatoEmail(resultado.getString("contato_email"));
                p.setCelular(resultado.getString("celular"));
                p.setLocalResidencia(resultado.getString("local_residencia"));
                lista.add(p);
            }
            conexao.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
}
// alanzin 3,14 <3