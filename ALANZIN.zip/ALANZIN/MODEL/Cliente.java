public class Pessoa {
    private int codigo;
    private String nomeCompleto;
    private String documento;
    private String contatoEmail;
    private String celular;
    private String localResidencia;

    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }
    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public String getDocumento() {
        return documento;
    }
    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getContatoEmail() {
        return contatoEmail;
    }
    public void setContatoEmail(String contatoEmail) {
        this.contatoEmail = contatoEmail;
    }

    public String getCelular() {
        return celular;
    }
    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getLocalResidencia() {
        return localResidencia;
    }
    public void setLocalResidencia(String localResidencia) {
        this.localResidencia = localResidencia;
    }
}
// alanzin 3,14 <3