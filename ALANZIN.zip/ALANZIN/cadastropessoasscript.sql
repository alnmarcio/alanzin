CREATE DATABASE IF NOT EXISTS CadastroPessoas;
USE CadastroPessoas;

CREATE TABLE IF NOT EXISTS registros (
    codigo INT AUTO_INCREMENT PRIMARY KEY,
    nome_completo VARCHAR(100) NOT NULL,
    documento VARCHAR(14) NOT NULL,
    contato_email VARCHAR(100),
    celular VARCHAR(20),
    local_residencia VARCHAR(255)
);

INSERT INTO registros (nome_completo, documento, contato_email, celular, local_residencia)
VALUES 
('Amanda Ribeiro', '123.456.789-00', 'amanda.ribeiro@email.com', '(11) 98765-4321', 'Rua das Acácias, 123 - São Paulo, SP'),
('Bruno Costa', '987.654.321-00', 'bruno.costa@email.com', '(21) 99887-6655', 'Av. Atlântica, 456 - Rio de Janeiro, RJ'),
('Carla Martins', '456.789.123-00', 'carla.martins@email.com', '(31) 97777-8899', 'Rua das Flores, 789 - Belo Horizonte, MG');
